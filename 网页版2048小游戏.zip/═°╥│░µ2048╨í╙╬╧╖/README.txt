这是一个网页版的2048小游戏
1.环境
	tomcat 9.0.76
	MySQL 5.7.21
	Java 18
2.需要的库
	json.jar
	fasrjson.jar
	mysql-connector.jar
	servlet.jar
	commons-lang3.jar
3.运行
先进入index.html
输入玩家姓名后进入游戏界面。